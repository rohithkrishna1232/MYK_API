# 🐧 Linux/macOS users: Setup Instructions

1. Run this once when project set up in terminal
chmod +x setup_and_run.sh

Other System Requirements:
Make sure Java JDK version installed >= 17

sudo apt update
sudo apt install openjdk-17-jre -y

2. Run this in your terminal to execute prompt each time:
./setup_and_run.sh


