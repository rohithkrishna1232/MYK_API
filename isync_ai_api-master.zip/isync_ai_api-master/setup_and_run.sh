#!/bin/bash
echo "[🔧] Creating virtual environment..."
python3 -m venv isync_api_api

echo "[✅] Activating virtual environment..."
source isync_api_api/bin/activate

echo "[⬇️] Installing dependencies..."
pip install -r requirements.txt

echo "[🚀] Running the prompt validator..."
python3 src/main.py