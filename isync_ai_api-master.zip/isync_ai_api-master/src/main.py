from packages.prompt_validator import PromptValidator
from packages.weaviate_client import WeaviateClient
import os


def main():

    try:

        # Use RAG-style retrieval
        weaviate_client = WeaviateClient()
        client = weaviate_client.create_client()
        question = "What is iSync Rabbit?"
        context_docs = weaviate_client.retrieve(question, top_k=3)

        print("📄 Retrieved Contexts:", context_docs)
        for i, doc in enumerate(context_docs, 1):
            print(f"{i}. {doc}")

        # Create collection
        '''weaviate_client = WeaviateClient()
        client = weaviate_client.create_client()
        collection = weaviate_client.create_weaviate_collection()

        # Chunk the text
        print(f"Testing Chunking document: {weaviate_client.DOCUMENT_PATH}")
        chunks = weaviate_client.chunk_text(
            file_path=weaviate_client.DOCUMENT_PATH,
            chunk_size=weaviate_client.CHUNK_SIZE,
            chunk_overlap=weaviate_client.CHUNK_OVERLAP
        )
        print(f"Document '{weaviate_client.DOCUMENT_PATH}' split into {len(chunks)} chunks.")

        # Upload to Weaviate
        weaviate_client.upload_chunks_to_weaviate(
            collection=collection,
            chunks=chunks,
            source_document_name=os.path.basename(
                weaviate_client.DOCUMENT_PATH)
        )'''
    except Exception as e:
        print(f"Main Block An error occurred: {e}")

    finally:
        print("Final Block:: Closing Weaviate client connection...")
        if client:
            client.close()

        # Prompt validation loop
    #     validator = PromptValidator()
    #     print("[🚀] Running the prompt validator (Press Ctrl+C or type 'exit' to quit)...\n")
    # finally:
    #     # Ensure the client is closed properly
    #     if client:
    #         client.close()
    #     while True:
    #         try:
    #             user_input = input("Enter your prompt: ")
    #             if user_input.lower() in ["exit", "quit"]:
    #                 print("👋 Exiting the validator.")
    #                 break

    #             result = validator.validate(user_input)

    #             if result["is_valid"]:
    #                 print("✅ Correct input prompt")
    #             else:
    #                 print("❌ Input seems invalid.")
    #                 for err in result["errors"]:
    #                     print("  -", err)

    #         except KeyboardInterrupt:
    #             print("\n👋 Exiting the validator.")
    #             break

    # finally:
        # 🔐 Always close the client connection here
        # if client:
        #     client.close()
        #     print("✅ Weaviate client connection closed.")


if __name__ == "__main__":
    main()
