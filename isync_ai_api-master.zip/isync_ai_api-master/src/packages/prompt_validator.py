from better_profanity import profanity
from langdetect import detect
import language_tool_python

class PromptValidator:
    def __init__(self):
        self.max_length = 1000
        self.language_tool = language_tool_python.LanguageTool('en-US')
        profanity.load_censor_words()

    def validate(self, prompt: str) -> dict:
        results = {
            "is_valid": True,
            "errors": [],
            "grammar_warnings": []
        }

        # Empty check
        if not prompt.strip():
            results["errors"].append("Prompt is empty.")
            results["is_valid"] = False
            return results

        # Length check
        if len(prompt) > self.max_length:
            results["errors"].append(f"Prompt is too long (over {self.max_length} characters).")
            results["is_valid"] = False

        # Profanity check
        if profanity.contains_profanity(prompt):
            results["errors"].append("Prompt contains inappropriate language.")
            results["is_valid"] = False

        # Language check
        try:
            lang = detect(prompt)
            if lang != 'en':
                results["errors"].append(f"Prompt is not in English (detected: {lang}).")
                results["is_valid"] = False
        except Exception as e:
            results["errors"].append(f"Language detection failed: {str(e)}")
            results["is_valid"] = False

        # Grammar check
        matches = self.language_tool.check(prompt)
        if matches:
            results["grammar_warnings"] = [match.message for match in matches[:3]]

        return results