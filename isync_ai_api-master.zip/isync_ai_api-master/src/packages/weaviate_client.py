import weaviate
from weaviate.classes.init import Auth
from weaviate.classes.config import Configure, VectorDistances
from dotenv import load_dotenv
import os
from typing import List
from sentence_transformers import SentenceTransformer


load_dotenv()


class WeaviateClient:
    def __init__(self):
        self.WEAVIATE_URL = os.environ["WEAVIATE_URL"]
        self.WEAVIATE_API_KEY = os.environ["WEAVIATE_API_KEY"]
        self.COLLECTION_NAME = os.environ["COLLECTION_NAME"]
        self.DOCUMENT_PATH = os.environ["DOCUMENT_PATH"]
        self.CHUNK_SIZE = int(os.environ.get("CHUNK_SIZE", 1000))
        self.CHUNK_OVERLAP = int(os.environ.get("CHUNK_OVERLAP", 100))
        self.MODEL = SentenceTransformer(
            "Snowflake/snowflake-arctic-embed-l-v2.0")
        self.client = None

    # Connect to Weaviate Cloud using the provided URL and API key
    # Returns a Weaviate client instance if successful, otherwise returns None
    # This method handles the connection to Weaviate and checks if the connection is ready
    def create_client(self):
        try:
            self.client = weaviate.connect_to_weaviate_cloud(
                cluster_url=self.WEAVIATE_URL,
                auth_credentials=Auth.api_key(self.WEAVIATE_API_KEY),
            )
            print("Weaviate connection success:", self.client.is_ready())
            return self.client
        except Exception as e:
            print(f"WeaviateClient - connection - Error: {e}")
            return None

    # Ensure the specified Weaviate collection exists
    # If the collection does not exist, it will create a new one with the specified configuration
    # This method checks for existing collections and creates a new one if it doesn't exist

    def _ensure_collection(self, collection_name: str = None):
        if collection_name not in self.client.collections.list_all():
            self.client.collections.create(
                name=collection_name,
                vectorizer_config=Configure.Vectorizer.none(),
                vector_index_config=Configure.VectorIndex.hnsw(
                    distance_metric=VectorDistances.COSINE,
                    ef_construction=128,
                    max_connections=64,
                ),
            )
            return self.client.collections.get(collection_name)
        else:
            print(f"Collection '{collection_name}' already exists.")
            return self.client.collections.get(collection_name)

    # Create a Weaviate collection with the specified name
    # If the collection already exists, it will not create a new one
    # Returns the collection object if successful, otherwise returns None
    # This method checks for existing collections and creates a new one if it doesn't exist
    # It uses the SentenceTransformer model for text encoding and sets up the vector index configuration
    # with HNSW (Hierarchical Navigable Small World) algorithm and cosine distance metric
    # The collection is created with no vectorizer configuration, meaning it will not use any additional
    # text processing or vectorization beyond what is provided by the SentenceTransformer model

    def create_weaviate_collection(self):
        try:
            existing_collections = self.client.collections.list_all()
            # print("Existing collections:", existing_collections)

            if self.COLLECTION_NAME in existing_collections:
                print(f"Collection '{self.COLLECTION_NAME}' already exists.")
            else:
                self.client.collections.create(
                    name=self.COLLECTION_NAME,
                    vectorizer_config=Configure.Vectorizer.none(),
                    vector_index_config=Configure.VectorIndex.hnsw(
                        distance_metric=VectorDistances.COSINE
                    ),
                )
                print(
                    f"Collection '{self.COLLECTION_NAME}' created successfully.")

            return self.client.collections.get(self.COLLECTION_NAME)

        except Exception as e:
            print(f"WeaviateClient - create_weaviate_collection - Error: {e}")
            return None

    # Split the text from the specified file into chunks of a given size with overlap
    # The chunks are created by reading the file and slicing the text into smaller parts
    # Each chunk is of size `chunk_size` and overlaps with the previous chunk by `chunk_overlap`
    # Returns a list of text chunks
    def chunk_text(self, file_path: str, chunk_size: int, chunk_overlap: int) -> List[str]:
        chunks = []
        with open(file_path, 'r', encoding='utf-8') as f:
            text = f.read()

        start_index = 0
        while start_index < len(text):
            end_index = min(start_index + chunk_size, len(text))
            chunk = text[start_index:end_index]
            chunks.append(chunk)
            if end_index == len(text):
                break
            start_index += (chunk_size - chunk_overlap)
            if start_index < 0:
                start_index = 0

        return chunks

    # Upload chunks to Weaviate collection
    # Each chunk is stored as an object with properties: chunk_id, text, and source_document
    # The text is encoded using the SentenceTransformer model
    # The source_document_name is the name of the original document from which the chunks were created
    # The upload is done in batches for efficiency
    # The batch size is set to 100, meaning every 100 chunks will be added
    # This helps in reducing the number of API calls and improves performance
    def upload_chunks_to_weaviate(self, collection, chunks: List[str], source_document_name: str):
        print(f"Starting upload of {len(chunks)} chunks to Weaviate...")

        with collection.batch.dynamic() as batch:
            for i, chunk in enumerate(chunks):
                embedding = self.MODEL.encode(chunk).tolist()
                properties = {
                    "chunk_id": i,
                    "text": chunk,
                    "source_document": source_document_name
                }
                batch.add_object(properties=properties, vector=embedding)
                if (i + 1) % 100 == 0:
                    print(f"Added {i + 1} chunks to batch...")
        print(f"Finished uploading {len(chunks)} chunks to Weaviate.")


    # Retrieve top_k similar text chunks from Weaviate based on the query
    # The query is encoded using the SentenceTransformer model
    # The method returns a list of text chunks that are most similar to the query
    # If the query is empty or consists only of whitespace, it returns an empty list
    def retrieve(self, query: str, top_k: int = 5) -> list[str]:
        if not query.strip():
            return []

        collection = self.client.collections.get(self.COLLECTION_NAME)
        query_vector = self.MODEL.encode(query).tolist()
        print(f"Collection: {collection}")

        response = collection.query.near_vector(
            near_vector=query_vector,
            limit=top_k
        )

        return [obj.properties["text"] for obj in response.objects]

    # Delete specified Weaviate collection safely
    def delete_weaviate_collection_safe(client: weaviate.WeaviateClient, collection_name: str):
        print(
            f"\n--- Initiating deletion for collection: '{collection_name}' ---")
        if not client.collections.exists(collection_name):
            print(
                f"Collection '{collection_name}' does not exist. No deletion needed.")
            return False
        else:
            try:
                client.collections.delete(collection_name)
                print(
                    f"Collection '{collection_name}' and all its data have been successfully DELETED.")
                return True
            except Exception as e:
                print(f"Error deleting collection '{collection_name}': {e}")
                return False
