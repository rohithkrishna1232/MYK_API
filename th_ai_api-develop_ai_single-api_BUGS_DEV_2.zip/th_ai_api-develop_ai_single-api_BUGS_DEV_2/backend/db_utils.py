import os
import mysql.connector
import logging
from logging.handlers import RotatingFileHandler
logger = logging.getLogger(__name__)
def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host=os.getenv("HOST"),
            user=os.getenv("USER"),
            port=os.getenv("PORT"),
            password=os.getenv("PASSWORD"),
            database=os.getenv("DATABASE"),
            auth_plugin='mysql_native_password'
        )
        if connection.is_connected():
            logger.info("Connected to the database successfully!")
            return connection
    except mysql.connector.Error as e:
        logger.error(f"Database connection error: {e}")
        return None