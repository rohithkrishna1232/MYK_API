# Task template
task_template = {
    "taskName": "Test rbn sep 16 task6",
    "taskType": "0",
    "taskDescription": "<p>test image desc</p>",
    "checkListType": None,
    "taskImage": None,
    "taskVideo": None,
    "staticCheckList": [],
    "checklistLabels": [],
    "checklistData": [],
    "startDate": "2024-09-15T18:30:00.000Z",
    "dueDate": "2024-09-16T18:30:00.000Z",
    "private": False,
    "isSignatureRequired": False,
    "geoFenceEnabled": False,
    "attachments": [],
    "priority": "normal",
    "saveAsTemplate": False,
    "templateName": "",
    "geoFenceRadius": 600,
    "geoFenceRadiusUnit": "meters",
    "tagsList": [],
    "userTags": [
        {"targetUserID": 11, "taskUserType": "assigned"}
    ],
    "locationTags": [],
    "departmentTags": [],
    "attachmentsRequiredForCompletion": False,
    "recurring": False
}
