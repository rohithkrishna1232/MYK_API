import jwt
from jwt.exceptions import InvalidTokenError
import os
from dotenv import load_dotenv
import logging
from jwt.exceptions import ExpiredSignatureError, DecodeError, PyJWTError
from logging.handlers import RotatingFileHandler
logger = logging.getLogger(__name__)
load_dotenv(".env")

SECRET_KEY = os.getenv("SECRET_KEY")
AlGORITHMS=os.getenv("AlGORITHMS")
def validate_token(token):
    """
    Validates a JWT token.
    Args:
        token (str): The JWT token to validate.
    Returns:
        dict: The decoded token payload if valid, None otherwise.
    """
    try:
        decoded = jwt.decode(token, SECRET_KEY, AlGORITHMS)
        return decoded
    except ExpiredSignatureError:
        logging.error("JWT signature has expired.")
        return None
    except DecodeError:
        logging.error("JWT decoding error.")
        return None
    except InvalidTokenError:
        logging.error("Invalid JWT token.")
        return None
    except PyJWTError as e:
        logging.error(f"PyJWT error: {e}")
        return None
    except Exception as e:
        logging.error(f"Unexpected JWT error: {e}")
        return None
