# Mylapore Catering App (Python/Django)

This is a monolithic Python/Django version of the Mylapore Catering Chat application.

## Prerequisites
- Python 3.8+
- Pip (Python package manager)

## Setup & Run

1. Install Python dependencies:

   ```bash
   pip install -r requirements.txt
   ```

2. (Optional) Install Node.js dependencies for Tailwind CSS:

   ```bash
   npm install
   ```

3. Apply database migrations:

   ```bash
   python manage.py migrate
   ```

4. Ensure you have an OpenAI API key set in your environment:

   ```bash
   export OPENAI_API_KEY="your_openai_api_key"
   ```

5. Run the development server:

   ```bash
   python manage.py runserver
   ```

5. Open http://127.0.0.1:8000/ in your browser.

## Project Structure

- `backend/` - Django project settings and URLs
- `chatbot/` - Django app containing views and AI logic
- `templates/` - Jinja2 templates for pages
- `static/` - Static assets (CSS, JS, images)
- `catering_data.json` - Catering menu data used by AI logic

## Next Steps

- AI flows have been ported into `chatbot/ai.py`. Configure your OpenAI key and try a chat!
- Integrate Tailwind CSS build for styling (`npm run build:css`).
