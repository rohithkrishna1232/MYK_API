document.addEventListener('DOMContentLoaded', () => {
  const chatForm = document.getElementById('chat-form');
  const chatInput = document.getElementById('chat-input');
  const chatLog = document.getElementById('chat-log');

  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const userMessage = chatInput.value.trim();
    if (!userMessage) return;
    appendMessage('user', userMessage);
    chatInput.value = '';
    try {
      const response = await fetch('/chat/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage }),
      });
      const data = await response.json();
      appendMessage('bot', data.reply);
      // Display suggested menu if provided
      if (data.suggested_menu && data.suggested_menu.menu_suggestions) {
        data.suggested_menu.menu_suggestions.forEach(item => {
          appendMessage('bot', `${item.dishName}: ${item.description}`);
        });
        if (data.suggested_menu.notes) {
          appendMessage('bot', data.suggested_menu.notes);
        }
      }
      // Display follow-up question if any
      if (data.follow_up) {
        appendMessage('bot', data.follow_up);
      }
    } catch (err) {
      appendMessage('bot', 'Error: Could not get response.');
    }
  });

  function appendMessage(sender, text) {
    const div = document.createElement('div');
    div.className = 'chat-message ' + sender;
    div.textContent = text;
    chatLog.appendChild(div);
    chatLog.scrollTop = chatLog.scrollHeight;
  }
});