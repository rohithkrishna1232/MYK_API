from flask import Flask, request, jsonify
from flask_cors import CORS
from .send_order_email import send_order_email           # ← relative import

app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "http://localhost:8000"}},
          methods=["GET","POST","OPTIONS"])

@app.route("/api/send", methods=["POST"])
def api_send():
    data = request.get_json(silent=True) or {}
    required = {'cart','customerName','phoneNumber','address','eventDateTime','email'}
    if not required.issubset(data):
        return jsonify({"status":"failed","error":"missing fields"}), 400

    ok = send_order_email(
        cart           = data['cart'],
        customer_name  = data['customerName'],
        phone_number   = data['phoneNumber'],
        address        = data['address'],
        event_datetime = data['eventDateTime'],
        user_email     = data['email']
    )
    return jsonify({"status":"success" if ok else "failed"}), 200

if __name__ == "__main__":
    app.run(host="localhost", port=5050, debug=True)
