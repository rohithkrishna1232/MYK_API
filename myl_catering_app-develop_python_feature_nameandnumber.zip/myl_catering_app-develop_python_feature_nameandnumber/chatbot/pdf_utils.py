from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from io import BytesIO
from datetime import datetime

def generate_order_pdf(cart, customer_name, phone_number, address, event_date_time):
    """
    Generate a catering order PDF with the given cart items and customer details.
    Returns PDF as bytes.
    """
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    y = height - 40

    # Company Name Header
    c.setFont("Helvetica-Bold", 20)
    c.drawString(50, y, "Mylapore Catering")
    y -= 30

    # Format event date and time
    try:
        dt = datetime.fromisoformat(event_date_time)
        formatted_date = dt.strftime("%m/%d/%Y")
        weekday = dt.strftime("%A")
        formatted_time = dt.strftime("%I:%M %p")
    except Exception:
        formatted_date = event_date_time
        weekday = ''
        formatted_time = ''

    c.setFont("Helvetica-Bold", 16)
    c.drawString(50, y, f"{formatted_date} – {weekday}")
    y -= 25
    c.setFont("Helvetica-Bold", 14)
    c.drawString(50, y, f"Time – {formatted_time}")
    y -= 40

    # Table headers
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, y, "Item")
    c.drawString(width - 200, y, "Quantity")
    y -= 20
    c.setFont("Helvetica", 12)
    # Menu items
    for item in cart:
        qty = item.get('quantityDetail') or (str(item.get('quantity')) if item.get('quantity') is not None else '')
        c.drawString(50, y, item.get('dishName', ''))
        c.drawString(width - 200, y, qty)
        y -= 20
    y -= 20

    # Standard note
    c.drawString(50, y, "Sambar and chutneys will be provided as required.")
    y -= 30

    # Customer details footer
    c.drawString(50, y, f"Customer: {customer_name}")
    y -= 18
    c.drawString(50, y, f"Phone: {phone_number}")
    y -= 18
    c.drawString(50, y, f"Address: {address}")

    c.showPage()
    c.save()
    pdf = buffer.getvalue()
    buffer.close()
    return pdf