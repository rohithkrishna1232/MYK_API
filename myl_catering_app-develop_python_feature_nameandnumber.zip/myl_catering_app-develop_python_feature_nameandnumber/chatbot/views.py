from django.shortcuts import render
import json
import base64
from io import BytesIO
from django.http import JsonResponse, HttpResponse, FileResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from datetime import datetime, timedelta
from dateutil import parser as date_parser
from re import sub as re_sub

from .ai import process_user_message, generate_quantity_estimate, extract_lead_info
from .pdf_utils import generate_order_pdf

def index(request):
    request.session['conversation'] = [{
        'sender': 'bot',
        'text': "👋 Hi! I'm Chef CHITTI, your AI catering assistant from Mylapore Catering. I specialize in South Indian cuisine and can help you plan the perfect menu for any event."
    }]
    request.session['event_details'] = {}
    request.session['suggested_menu_items'] = []
    request.session['finalized_pdf'] = None
    return render(request, 'index.html')

def download_order(request):
    encoded_pdf = request.session.get('finalized_pdf')
    if not encoded_pdf:
        return HttpResponse("No finalized order found.", status=404)

    pdf_bytes = base64.b64decode(encoded_pdf)
    return FileResponse(BytesIO(pdf_bytes), as_attachment=True, filename="mylapore_order.pdf")

@csrf_exempt
@require_POST
def chat(request):
    try:
        data = json.loads(request.body)
        user_message = data.get('message', '').strip()
        conv = request.session.get('conversation', [])
        event_details = request.session.get('event_details', {})

        conv.append({'sender': 'user', 'text': user_message})
        previous_details = event_details.copy()

        name = event_details.get("user_name")
        phone = event_details.get("user_phone")

        if not name or not phone:
            lead_data = extract_lead_info(user_message)
            if not name and lead_data.get("user_name"):
                name_candidate = lead_data["user_name"].strip().title()
                if len(name_candidate) >= 2 and name_candidate.replace(" ", "").isalpha():
                    event_details["user_name"] = name_candidate
                    name = name_candidate
            if not phone and lead_data.get("user_phone"):
                raw_phone = lead_data["user_phone"]
                clean_phone = re_sub(r"[^\d]", "", raw_phone)
                if 10 <= len(clean_phone) <= 15:
                    event_details["user_phone"] = clean_phone
                    phone = clean_phone
                else:
                    print("❌ Invalid phone detected from AI:", raw_phone)

            request.session["event_details"] = event_details

            if not name or not phone:
                prompt = "👋 Before we begin, may I have your name and phone number?"
                if name and not phone:
                    prompt = f"Thanks, {name}! Could you share a valid phone number (10–15 digits)?"
                elif phone and not name:
                    prompt = "Got your number. May I know your name, please?"

                return JsonResponse({
                    'reply': prompt,
                    'event_details': event_details,
                    'follow_up': None,
                    'suggested_menu': None,
                    'quantities': [],
                })

            greeting = (
            f"Thanks, {name}! Lovely to meet you. "
            "To help you better, could you share the event details — like number of guests, date, pickup time, and your preferred location?"
            )
            conv.append({'sender': 'bot', 'text': greeting})
            request.session["conversation"] = conv
            return JsonResponse({
                'reply': greeting,
                'event_details': event_details,
                'follow_up': None,
                'suggested_menu': None,
                'quantities': [],
            })

        result = process_user_message(user_message, conv, event_details)
        updated_details = result.get('updated_event_details') or event_details
        if event_details.get("user_name") and not updated_details.get("user_name"):
            updated_details["user_name"] = event_details["user_name"]
        if event_details.get("user_phone") and not updated_details.get("user_phone"):
            updated_details["user_phone"] = event_details["user_phone"]
        retry_count = request.session.get('retry_count', 0)
        if updated_details == previous_details:
            retry_count += 1
        else:
            retry_count = 0
        request.session['retry_count'] = retry_count

        event_date_str = (updated_details.get('event_date') or '').strip()
        if event_date_str:
            try:
                event_date = date_parser.parse(event_date_str)
                if event_date < datetime.now() + timedelta(days=2):
                    return JsonResponse({
                        'reply': "Will contact you soon! Stay tuned for updates. As the selected date is too close.",
                        'follow_up': None,
                        'suggested_menu': None,
                        'quantities': [],
                    })
            except Exception as e:
                print("❌ Invalid date format:", e)

        request.session['event_details'] = updated_details

        fallback_messages = {
            1: "Namaste! Could you please share the number of guests, event date, pickup time, and preferred location?",
            2: "Still waiting on the details: guest count, date, time, and pickup location (Downtown or Uptown).",
            3: "To help you best, I need info like: '50 guests on June 20 at 10am, Downtown'.",
            4: "🙏 I'm still waiting. Please provide the event details so I can help you properly.",
        }

        if retry_count > 0 and retry_count <= 4 and result.get('reply', '').strip() == "":
            result['reply'] = fallback_messages[retry_count]

        bot_entry = {'sender': 'bot', 'text': result.get('reply', '')}

        suggested_menu = result.get('suggested_menu')
        if isinstance(suggested_menu, dict) and suggested_menu.get('menu_suggestions'):
            request.session['suggested_menu_items'] = suggested_menu['menu_suggestions']

        if result.get('follow_up_question'):
            bot_entry['follow_up'] = result['follow_up_question']

        guest_count = updated_details.get('guest_count')
        all_menu = request.session.get('suggested_menu_items', {})
        selected_menu = []

        if all_menu:
            for category in all_menu.values():
                for item in category:
                    name = item.get('dishName', '').lower()
                    if name and name in user_message.lower():
                        selected_menu.append(item)

            if selected_menu and guest_count:
                estimate_result = generate_quantity_estimate(selected_menu, guest_count, all_menu)
                explanation = estimate_result.get("explanation", "")
                quantities = estimate_result.get("quantities", [])

                if result.get("quantity_explanation"):
                    print("🧐 AI REASONING LOG:", explanation)

                if quantities:
                    lines = [f"Here are the recommended quantities based on your selections:"]
                    for dish in quantities:
                        lines.append(f"- {dish['dishName']}: {dish['recommended_quantity']} {dish['unit']}")

        if result.get('is_final_confirmation') and isinstance(suggested_menu, dict):
            menu = suggested_menu.get('menu_suggestions', [])
            pdf_bytes = generate_order_pdf(
                cart=menu,
                customer_name=event_details.get('user_name', 'Customer'),
                phone_number=event_details.get('user_phone', 'N/A'),
                address=event_details.get('location', ''),
                event_date_time=event_details.get('event_date', '')
            )
            request.session['finalized_pdf'] = base64.b64encode(pdf_bytes).decode('utf-8')
            bot_entry['text'] += "\n✅ Your order has been finalized! You can download the order summary below."
            bot_entry['download_link'] = "/download_order/"

        conv.append(bot_entry)
        request.session['conversation'] = conv

        response_data = {
            'reply': bot_entry['text'],
            'follow_up': result.get('follow_up_question'),
            'suggested_menu': result.get('suggested_menu'),
            'quantities': result.get('quantities', []),
            'event_details': updated_details,
        }

        if bot_entry.get('download_link'):
            response_data['download_link'] = bot_entry['download_link']

        return JsonResponse(response_data)

    except Exception as e:
        return JsonResponse({'reply': f"Error: {str(e)}"}, status=500)
