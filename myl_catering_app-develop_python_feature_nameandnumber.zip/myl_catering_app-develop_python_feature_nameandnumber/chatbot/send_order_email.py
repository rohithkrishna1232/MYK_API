"""
Send catering-order confirmation e-mail with a neatly-formatted PDF
------------------------------------------------------------------
Requires:  python-dotenv, reportlab, python-dateutil  (pip install python-dateutil)

Environment variables (in .env):
    EMAIL_FROM     – Gmail address that sends the mail
    EMAIL_PASS     – Gmail *app* password
    COMPANY_EMAIL  – Address that always receives a copy
"""

import os
import smtplib
from io import BytesIO
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text     import MIMEText
from email.mime.application import MIMEApplication

from dotenv import load_dotenv
from dateutil import parser as date_parser        # <-- NEW
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen        import canvas
from reportlab.pdfbase.pdfmetrics import stringWidth

# ─────────────────────────────────────────────────────────────────────────────
STYLE = {
    "title_font":   ("Helvetica-Bold", 18),
    "subhead_font": ("Helvetica-Bold", 14),
    "body_font":    ("Helvetica",      12),
    "left_margin":   50,
    "right_margin":  560,
    "row_height":    18,
    "page_top":     760,
}

load_dotenv()
EMAIL_FROM = os.getenv("EMAIL_FROM")
EMAIL_PASS = os.getenv("EMAIL_PASS")
COMPANY_TO = os.getenv("COMPANY_EMAIL", "")

# ─────────────────────────────────────────────────────────────────────────────
def _parse_dt(value) -> datetime | None:
    """Return a datetime if *value* can be parsed, else None."""
    if isinstance(value, datetime):
        return value
    try:
        return date_parser.parse(str(value))
    except (ValueError, TypeError):
        return None

# ─────────────────────────────────────────────────────────────────────────────
def _build_pdf(cart: list[dict],
               customer: str, phone: str, address: str,
               event_datetime) -> bytes:
    buf = BytesIO()
    pdf = canvas.Canvas(buf, pagesize=letter)
    s   = STYLE

    dt = _parse_dt(event_datetime)         # datetime or None
    day  = dt.strftime("%A")              if dt else ""
    date = dt.strftime("%m/%d/%Y")        if dt else str(event_datetime)
    time = dt.strftime("%I:%M %p").lstrip("0") if dt else ""

    y = s["page_top"]

    # ── Title with day-of-week ───────────────────────────────────────────────
    pdf.setFont(*s["title_font"])
    title = f"{address} Catering Order ({day})" if day else "Mylapore Catering Order"
    pdf.drawCentredString(letter[0] / 2, y, title)
    y -= 30

    # ── Date & Time lines ────────────────────────────────────────────────────
    pdf.setFont(*s["subhead_font"])
    pdf.drawCentredString(letter[0] / 2, y, f"Date – {date}")
    y -= 22
    if time:
        pdf.drawCentredString(letter[0] / 2, y, f"Time – {time}")
        y -= 22
    pdf.line(s["left_margin"], y, s["right_margin"], y)
    y -= 25

    # ── Customer block ───────────────────────────────────────────────────────
    pdf.setFont(*s["body_font"])
    for label, value in (("Name", customer),
                         ("Phone", phone),
                         ("Address", address)):
        pdf.drawString(s["left_margin"], y, f"{label}: {str(value)}")
        y -= 16
    y -= 12

    # ── Items list ───────────────────────────────────────────────────────────
    max_dish_width = max(
        stringWidth(str(i.get("dishName", "")), *s["body_font"])
        for i in cart
    ) + 10
    qty_x = letter[0] / 2

    pdf.drawString(s["left_margin"], y, "Items:")
    pdf.drawString(qty_x + 10, y, "Qty")
    y -= 20

    for item in cart:
        dish = str(item.get("dishName", ""))
        qty  = str(item.get("quantityDetail") or item.get("quantity") or "")
        pdf.drawString(s["left_margin"], y, dish)
        pdf.drawString(qty_x, y, "-")
        qty_w = stringWidth(qty, *s["body_font"])
        pdf.drawString(qty_x + 10, y, qty)
        y -= s["row_height"]

    pdf.save()
    buf.seek(0)
    return buf.getvalue()

# ─────────────────────────────────────────────────────────────────────────────
def send_order_email(cart: list[dict], customer_name: str,
                     phone_number: str, address: str,
                     event_datetime, user_email: str) -> bool:
    try:
        pdf_bytes = _build_pdf(cart, customer_name, phone_number,
                               address, event_datetime)

        msg = MIMEMultipart()
        msg["Subject"] = f"New Catering Order – {customer_name}"
        msg["From"]    = EMAIL_FROM
        msg["To"]      = ", ".join(filter(None, [COMPANY_TO, user_email]))

        summary = "\n".join(
            f"{str(i.get('dishName'))} – {i.get('quantityDetail') or i.get('quantity')}"
            for i in cart
        )
        body = (f"Please find the attached catering order for {customer_name}.\n\n"
                f"Order Summary:\n{summary}")
        msg.attach(MIMEText(body, "plain"))

        attach = MIMEApplication(pdf_bytes, _subtype="pdf")
        attach.add_header("Content-Disposition", "attachment",
                          filename="order_summary.pdf")
        msg.attach(attach)

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(EMAIL_FROM, EMAIL_PASS)
            smtp.sendmail(EMAIL_FROM,
                          [addr for addr in (COMPANY_TO, user_email) if addr],
                          msg.as_string())
        print("📬  Email sent successfully.")
        return True

    except Exception as err:
        print("❌  Email error:", err)
        return False

# ─────────────────────────────────────────────────────────────────────────────
