#!/usr/bin/env python
"""Django's command-line utility for administrative tasks, plus an optional
Flask mail micro-service that starts automatically when you run `runserver`.
"""
import os
import sys
import subprocess
import signal
from pathlib import Path

# ------------------------------------------------------------
# Configuration – change ports or the dotted import here only
# ------------------------------------------------------------
FLASK_MODULE = "chatbot.email_api"    # where your Flask app lives
FLASK_PORT   = "5050"                 # must match front-end fetch()
FLASK_HOST   = "localhost"            # 0.0.0.0 for Docker
# ------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent

def start_flask():
    """Spawn the Flask dev-server with live-reload enabled."""
    env = os.environ.copy()
    env.setdefault("FLASK_APP", FLASK_MODULE)
    env.setdefault("FLASK_ENV", "development")  # enables reloader & debugger
    return subprocess.Popen(
        [sys.executable, "-m", "flask",
         "run", "--host", FLASK_HOST, "--port", FLASK_PORT],
        cwd=PROJECT_ROOT,
        env=env,
    )

def main() -> None:
    """Run administrative tasks (stock Django) + optional Flask."""
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "backend.settings")

    # Decide if we should fire up Flask as well
    launch_flask = len(sys.argv) >= 2 and sys.argv[1] == "runserver"

    if launch_flask:
        flask_proc = start_flask()
        print(
            f"🚀 Flask mailer running on http://{FLASK_HOST}:{FLASK_PORT} "
            f"(PID {flask_proc.pid})"
        )

    try:
        from django.core.management import execute_from_command_line
        execute_from_command_line(sys.argv)          # ← blocks until Ctrl-C
    finally:
        # Cleanly terminate Flask if it was started
        if launch_flask and flask_proc.poll() is None:
            print("\n⏳ Stopping Flask mailer …")
            flask_proc.send_signal(signal.SIGINT)
            flask_proc.wait()

if __name__ == "__main__":
    main()
