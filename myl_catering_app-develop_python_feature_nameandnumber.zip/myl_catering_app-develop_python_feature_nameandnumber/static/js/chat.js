document.addEventListener('DOMContentLoaded', () => {
  const chatForm = document.getElementById('chat-form');
  const chatInput = document.getElementById('chat-input');
  const chatLog = document.getElementById('chat-log');

  chatForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const userMessage = chatInput.value.trim();
    if (!userMessage) return;
    appendMessage('user', userMessage);
    chatInput.value = '';
    try {
      const response = await fetch('/chat/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage }),
      });
      const data = await response.json();
      appendMessage('bot', data.reply);

      if (data.suggested_menu && data.suggested_menu.menu_suggestions) {
        data.suggested_menu.menu_suggestions.forEach(item => {
          let text = `${item.dishName}: ${item.description}`;
          if (item.recommendation) {
            if (item.recommendation.type === 'piece') {
              text += ` (Qty: ${item.recommendation.total_pieces} pieces)`;
            } else if (item.recommendation.type === 'tray') {
              const trays = Object.entries(item.recommendation.tray_breakdown || {})
                .map(([size, count]) => `${count} ${size}`)
                .join(', ');
              text += ` (Qty: ${trays})`;
            }
          }
          appendMessage('bot', text);
        });
        if (data.suggested_menu.notes) {
          appendMessage('bot', data.suggested_menu.notes);
        }
      }

      if (data.follow_up) {
        appendMessage('bot', data.follow_up);
      }

      // Add download link if available
      if (data.download_link) {
        const link = document.createElement('a');
        link.href = data.download_link;
        link.textContent = '📄 Download Order Summary';
        link.className = 'chat-message bot download-link';
        link.target = '_blank';
        chatLog.appendChild(link);
        chatLog.scrollTop = chatLog.scrollHeight;
      }

    } catch (err) {
      appendMessage('bot', 'Error: Could not get response.');
    }
  });

  function appendMessage(sender, text) {
    const div = document.createElement('div');
    div.className = 'chat-message ' + sender;
    div.textContent = text;
    chatLog.appendChild(div);
    chatLog.scrollTop = chatLog.scrollHeight;
  }
});
