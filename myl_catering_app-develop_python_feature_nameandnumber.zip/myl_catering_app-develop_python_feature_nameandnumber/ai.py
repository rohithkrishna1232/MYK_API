import os
import json
import re
import google.generativeai as genai
from dotenv import load_dotenv
from datetime import datetime, timedelta
load_dotenv()

GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
if GOOGLE_API_KEY:
    genai.configure(api_key=GOOGLE_API_KEY)
else:
    raise ValueError("GOOGLE_API_KEY not found in environment variables.")

_catering_data = None

def load_catering_data():
    global _catering_data
    if _catering_data is None:
        with open('catering_data.json', 'r', encoding='utf-8') as f:
            _catering_data = json.load(f)
    return _catering_data

# def generate_quantity_estimate(selected_items: list, guest_count: int, available_menu: dict) -> list:
#     prompt = (
#         "You are a smart catering assistant for a South Indian vegetarian restaurant. "
#         "Your job is to estimate recommended quantities for selected dishes based on the guest count and the nature of the dishes. "
#         "Use the dish's quantity type and available tray sizes to decide the best portion. \n"
        # "- For 'piece', assume ~2–3 per guest.\n"
        # "- For 'tray', pick an appropriate tray size (Half / Medium / Large).\n"
        # "- For 'meals' or sets like Executive Thali, assume 1 per guest. Also return the same information in the quantity estm\n\n"
#         "Respond in JSON array format like:\n"
#         "[\n"
#         "  {\"dishName\": \"Idly\", \"recommended_quantity\": 100, \"unit\": \"pieces\"},\n"
#         "  {\"dishName\": \"Pongal\", \"recommended_quantity\": \"Medium\", \"unit\": \"tray\"}\n"
#         "]\n\n"
#         f"Guest Count: {guest_count}\n"
#         f"Selected Dishes: {json.dumps(selected_items)}\n"
#         f"Available Menu Data: {json.dumps(available_menu)}"
#     )

#     try:
#         model = genai.GenerativeModel(model_name="gemini-2.0-pro")
#         response = model.generate_content(prompt)
#         text = response.text.strip()
#         print("DEBUG - AI Response:", text)  # Debugging line to see raw AI response
#         if text.startswith("```json") or text.startswith("```"):
#             text = re.sub(r"^```(?:json)?", "", text).strip()
#             text = re.sub(r"```$", "", text).strip()

#         if not text.startswith("["):
#             raise ValueError(f"Unexpected response format: {text}")

#         return json.loads(text)

#     except Exception as e:
#         print("ERROR in generate_quantity_estimate:", str(e))
#         return []

def process_user_message(user_message: str, current_conversation: list, current_event_details: dict) -> dict:
    data = load_catering_data()
    locations = [loc['name'] for loc in data.get('locations', [])]

    available_menu = None
    proc_output = _call_llm_conversation(user_message, current_conversation,
                                         current_event_details, available_menu, locations)

    updated_event_details = proc_output.get('updated_event_details', current_event_details)
    date_str = updated_event_details.get("event_date")
    time_str = updated_event_details.get("pickup_time")

    if date_str and time_str:
        try:
            full_dt = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %I:%M %p")
            updated_event_details["event_datetime"] = full_dt.strftime("%Y-%m-%d %H:%M:%S")
        except Exception as e:
            print("⚠️ Failed to parse date and time:", e)
    if date_str and not time_str:
        return {
            "reply": "🕒 What time would you like to pick up the order on that date?",
            "updated_event_details": updated_event_details,
            "follow_up_question": None,
            "suggested_menu": None,
            "is_final_confirmation": False,
            "quantities": []
        }
    selected_location = (updated_event_details.get('location') or '').strip().lower()
    print("DEBUG - Selected Location:", selected_location)
    print("DEBUG - Updated Event Details:", updated_event_details)
    available_menu = None
    if selected_location:
        for loc in data['locations']:
            if loc['name'].strip().lower() == selected_location.strip().lower():
                available_menu = loc.get('menus') or {}
                break
        if available_menu is None:
            available_menu = {}
    required_fields = ["guest_count", "event_date", "pickup_time", "location"]
    has_all_required = all(
        proc_output.get('updated_event_details', {}).get(field)
        for field in required_fields
    )
    if has_all_required and user_message.strip().lower() in {"yes", "ok", "sure", "show menu", "please show menu"}:
        proc_output['should_generate_menu'] = True
        proc_output['bot_intends_to_suggest'] = True

    unsupported_dishes = ["chicken", "biryani", "mutton", "fish"]
    if any(word in user_message.lower() for word in unsupported_dishes):
        warning = "Note: Non-vegetarian items like Chicken Biryani are not part of our menu."
        proc_output['reply'] = f"{warning} Here's the standard menu instead."
        proc_output['should_generate_menu'] = True
        proc_output['bot_intends_to_suggest'] = True

    # Handle menu display logic
    menu_logic = _handle_menu_logic(
        should_generate_menu=proc_output.get('should_generate_menu', False),
        user_asked_for_menu=proc_output.get('user_asked_for_menu', False),
        bot_intends_to_suggest=proc_output.get('bot_intends_to_suggest', False),
        has_minimum_details=proc_output.get('has_minimum_details', False),
        event_details=updated_event_details,
        available_locations=locations,
        available_menu=available_menu
    )

    # NEW: Handle quantity estimation after dish selection
    # if updated_event_details.get("menu_shown", False) and not updated_event_details.get("quantities_suggested", False):
    #     selected_items = [item.strip().lower() for item in re.split(r',|\n', user_message)]

    #     matched_dishes = []
    #     for category, dishes in available_menu.items():
    #         for dish in dishes:
    #             name = dish.get("dishName", "").lower()
    #             if name in selected_items:
    #                 matched_dishes.append(dish)

    #     if matched_dishes:
    #         guest_count = updated_event_details.get("guest_count")
    #         print("DEBUG - Guest Count for Quantity Estimation:", guest_count)
    #         result = generate_quantity_estimate(matched_dishes, guest_count, available_menu)
    #         quantities = result.get("quantities", [])
    #         print("DEBUG - AI Quantity Estimate:", quantities)
    #         explanation = result.get("explanation", "")
    #         print("DEBUG - AI Quantity Estimate Result:", explanation)

    #     # 👇 Log the reasoning in the backend only
    #     # print("\n DEBUG - AI Quantity Explanation:\n", explanation)

    #         updated_event_details["quantities_suggested"] = True

    #         return {
    #             "reply": "Here are the recommended quantities based on your selections:\n" +
    #                     "\n".join([f"- {d['dishName']}: {d['recommended_quantity']} {d['unit']}" for d in quantities]),
    #             "updated_event_details": updated_event_details,
    #             "follow_up_question": "Would you like to confirm this order?",
    #             "suggested_menu": None,
    #             "is_final_confirmation": False,
    #             "quantity_explanation": explanation
    #         }

    # Always recalculate if the message contains selected dish names
    if updated_event_details.get("menu_shown", False):
        selected_items = [item.strip().lower() for item in re.split(r',|\n', user_message)]

        matched_dishes = []
        for category, dishes in available_menu.items():
            for dish in dishes:
                name = dish.get("dishName", "").lower()
                if name in selected_items:
                    matched_dishes.append(dish)

        if matched_dishes:
            guest_count = updated_event_details.get("guest_count", 50)  # fallback default
            print("DEBUG - Guest Count for Quantity Estimation:", guest_count)
            result = generate_quantity_estimate(matched_dishes, guest_count, available_menu)
            print("DEBUG - AI Quantity Estimate:", result)
            quantities = result.get("quantities", [])
            print("DEBUG - AI Quantity Estimate Result:",quantities)
            explanation = result.get("explanation", "")

            updated_event_details["quantities_suggested"] = True
            updated_event_details["selected_dishes"] = [dish['dishName'] for dish in matched_dishes]

            return {
                "reply": "Updated quantities based on your selected items:\n" +
                         "\n".join([f"- {d['dishName']}: {d['recommended_quantity']} {d['unit']}" for d in quantities]),
                "updated_event_details": updated_event_details,
                "follow_up_question": "Need any adjustments before checkout?",
                "suggested_menu": None,
                "is_final_confirmation": False,
                "quantity_explanation": explanation,
                "quantities": quantities  # 👈 Add this key for the frontend
            }
        
    result = {
    'reply': menu_logic.get('reply') or proc_output.get('reply', ''),
    'updated_event_details': updated_event_details,
    'follow_up_question': menu_logic.get('follow_up_question'),
    'suggested_menu': menu_logic.get('suggested_menu'),
    'is_final_confirmation': proc_output.get('is_final_confirmation', False),
    'quantities': []  # Always included for safe frontend handling
    }


    # result = {
    #     'reply': menu_logic.get('reply') or proc_output.get('reply', ''),
    #     'updated_event_details': updated_event_details,
    #     'follow_up_question': menu_logic.get('follow_up_question'),
    #     'suggested_menu': menu_logic.get('suggested_menu'),
    #     'is_final_confirmation': proc_output.get('is_final_confirmation', False)
    # }

    print("DEBUG - Final AI result:", result)
    return result


def _call_llm_conversation(user_input, conversation, event_details, available_menu, locations):
    system_prompt = (
        "You are 'Chef CHITTI', a friendly and helpful AI assistant for Mylapore Catering specializing in South Indian vegetarian cuisine. "
        "You're an expert South Indian catering assistant for Mylapore Catering. Events are not hosted at the restaurant."
        "Your job is to understand the user's event requirements, extract all relevant details in one go, and update the event context accordingly. "
        "While picking the restaurant location always show the user the available locations and ask them to pick one. Also use your smartness in picking the location if the user mentions a specific name or location. if user gives downtown you need to pick mylapore downtown. "
        "you should be able to understand the user meaning and intent behind the message. and match them according to the available locations and menu items."
        "Only collect these 4 required details: guest count, event date, event time, and location (which restaurant). "
        "Do not ask about event type."
        "Avoid listing information using bullet points or stars. Write your replies in natural human language — polite, flowing sentences, not structured lists or forms."
        "Always remember to return the date as ISO 8601 format but remeber to keep space between date and time, replace 'T' with a space. (YYYY-MM-DD 00:00:00)"
        "Collect both event date and pickup time. Extract them separately:\n"
        "- event_date (format: YYYY-MM-DD)\n"
        "- pickup_time (format: HH:MM AM/PM)\n"
        "Only proceed to suggest the menu when all 3 are collected: guest_count, event_date, pickup_time, and location.\n"
        "Do not default to midnight or 00:00 time. Ask for pickup time explicitly if missing.\n"
        "Return both fields in 'updated_event_details'."
        "If any of the 3 details are missing, politely ask only for the missing ones. "
        "Once all 3 are collected, do NOT include the menu in your reply. Instead, just set 'should_generate_menu': true and let the system handle menu display."
        "Avoid asking questions if the information can be inferred. Only ask for details that are truly missing. "
        "Do not reconfirm any detail unless it’s unclear or conflicting. "
        "Do NOT assume non-vegetarian requests are valid. Our menu is purely vegetarian. "
        "When the user seems to express agreement or intent to view the menu (even in natural language), set 'should_generate_menu': true and 'bot_intends_to_suggest': true"
        "Respond ONLY in raw JSON format with the following keys:\n"
        "Do not assume is_final_confirmation is True unless explicitly stated by the user. This will be given by the user once the user is happy with the count and quantities of the order\n"
        "- reply (string)\n"
        "- updated_event_details (object)\n"
        "- follow_up_question (string or null)\n"
        "- should_generate_menu (bool)\n"
        "- user_asked_for_menu (bool)\n"
        "- bot_intends_to_suggest (bool)\n"
        "- has_minimum_details (bool)\n"
        "- is_final_confirmation (bool)\n"
        "Do not include markdown or code blocks like ```json."
    )

    combined_user_message = (
        f"{system_prompt}\n\n"
        f"User Input: {user_input}\n"
        f"Event Details: {json.dumps(event_details)}\n"
        f"Conversation History: {json.dumps(conversation)}\n"
        f"Available Locations: {locations}\n"
        f"Available Menu: {json.dumps(available_menu) if available_menu else 'None'}"
    )

    try:
        model = genai.GenerativeModel(model_name="gemini-2.0-flash")

        response = model.generate_content([{"role": "user", "parts": [combined_user_message]}])

        content = response.text.strip() if response and response.text else ""

        if content.startswith("```json") or content.startswith("```"):
            content = re.sub(r"^```(?:json)?", "", content).strip()
            content = re.sub(r"```$", "", content).strip()

        if not content or not re.match(r'^\s*[{[]', content):
            raise ValueError(f"LLM response not in JSON format: {content}")

        return json.loads(content)

    except Exception as e:
        print("EXCEPTION in _call_llm_conversation:", str(e))
        return {
            'reply': f"Sorry, I had trouble understanding. ({str(e)})",
            'updated_event_details': event_details,
            'follow_up_question': None,
            'should_generate_menu': False,
            'user_asked_for_menu': False,
            'bot_intends_to_suggest': False,
            'is_final_confirmation': None,
            'has_minimum_details': False
        }

def _handle_menu_logic(should_generate_menu, user_asked_for_menu, bot_intends_to_suggest,
                       has_minimum_details, event_details, available_locations,
                       available_menu):
    output = {}

    if should_generate_menu and has_minimum_details and not event_details.get('menu_shown', False):
        if not available_menu:
            output['reply'] = "Sorry, the menu could not be loaded for the selected location."
            output['follow_up_question'] = None
            return output

        menu_text = "Here is the menu based on your selected location."

        output['suggested_menu'] = {
            'menu_suggestions': available_menu,
            'notes': menu_text
        }
        #output['reply'] = menu_text
        output['follow_up_question'] = None
        event_details['menu_shown'] = True

    elif (user_asked_for_menu or bot_intends_to_suggest) and not has_minimum_details:
        missing_fields = []
        if not event_details.get('location'):
            missing_fields.append("pickup location")
        if not event_details.get('guest_count'):
            missing_fields.append("guest count")
        if not event_details.get('event_date'):
            missing_fields.append("event date")

        if missing_fields:
            output['reply'] = (
                f"To proceed, I just need the following detail(s): {', '.join(missing_fields)}."
            )
            output['follow_up_question'] = None
        else:
            output['reply'] = None
            output['follow_up_question'] = None
    else:
        output['reply'] = None
        output['follow_up_question'] = None

    return output

# ✅ NEW FUNCTION: Quantity Estimation
def generate_quantity_estimate(selected_items: list, guest_count: int, available_menu: dict) -> dict:
    """
    Uses Gemini to intelligently calculate recommended quantities and returns explanation + quantities.
    """
    print("🧠 Generating quantity estimate for selected items:", selected_items, "for", guest_count, "guests")
    prompt = (
    "You are a smart AI-based catering assistant for a South Indian vegetarian restaurant. "
    "Your job is to calculate **recommended food quantities** for a **BUFFET-style** event using:\n"
    "- Guest count\n"
    "- Selected menu items\n"
    "- Metadata for each item (like serving unit, tray sizes, and item descriptions)\n\n"

    "Behave like an experienced human planner who knows how Indian buffet guests eat:\n"
    "- For full meal sets (like 'Executive Thali', 'Lunch Thali', 'Lunch Sets'), assume every guest takes one.\n"
    "- When such full meals are present, reduce side dishes and snacks to avoid duplication.\n"
    "- For items served in 'pieces', intelligently assume guests may take 1 to 2 per person depending on menu density, dish richness, and how many other options exist.\n"
    "- For 'tray'-based dishes, choose from:\n"
    "  • Half Tray: serves ~10–15 guests\n"
    "  • Medium Tray: serves ~15–20 guests\n"
    "  • Large Tray: serves ~20–25 guests\n"
    "- Remember this is a buffet, so guests sample — they don’t eat everything in full. Adjust quantities across overlapping dishes.\n"
    "- Include ~10% buffer for seconds, waste, and flexibility.\n"
    "- Avoid rigid math — use your knowledge of dish popularity, fill-factor, and complementary combinations to balance the servings.\n\n"
    "**Important:** Return all numeric quantities in rounded, real-world values:\n"
    "- Round 'pieces' to the nearest **5 or 10** — e.g., 80, 85, or 90 — no odd numbers like 83.\n"
    "- Round trays to the nearest **whole number** or use labeled tray sizes like '2 Large'.\n"
    "- Do not return overly precise or fractional values.\n\n"
    "Your response must be JSON-only in this format:\n"
    "{\n"
    "  \"explanation\": \"<how you reasoned about dish types, guest behavior, and menu balance>\",\n"
    "  \"quantities\": [\n"
    "    {\"dishName\": \"<Dish Name>\", \"recommended_quantity\": <amount>, \"unit\": \"<pieces/trays/meals>\"}\n"
    "  ]\n"
    "}\n\n"

    f"Guest Count: {guest_count}\n"
    f"Selected Dishes: {json.dumps(selected_items)}\n"
    f"Available Menu Data: {json.dumps(available_menu)}"
    )
    

    try:
        model = genai.GenerativeModel(model_name="gemini-2.0-flash")
        response = model.generate_content(prompt)
        text = response.text.strip()

        if text.startswith("```json") or text.startswith("```"):
            text = re.sub(r"^```(?:json)?", "", text).strip()
            text = re.sub(r"```$", "", text).strip()

        parsed = json.loads(text)

        if not isinstance(parsed, dict) or "quantities" not in parsed:
            raise ValueError(f"Unexpected response format: {text}")

        return parsed  # Contains both 'quantities' and 'explanation'

    except Exception as e:
        print("ERROR in generate_quantity_estimate:", str(e))
        return {
            "explanation": "Could not generate explanation due to an error.",
            "quantities": []
        }
